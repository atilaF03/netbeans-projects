/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.com.exemplo.atividade;

import Telas.Login;

/**
 *
 * @author aluno.den
 */
public class Atividade {

    public static void main(String[] args) {
        Login l = new Login();
        l.setVisible(true);
    }
}
